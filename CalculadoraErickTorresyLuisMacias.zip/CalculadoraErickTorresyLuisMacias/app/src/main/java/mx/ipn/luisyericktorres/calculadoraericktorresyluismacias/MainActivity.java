package mx.ipn.luisyericktorres.calculadoraericktorresyluismacias;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.math.*;

public class MainActivity extends AppCompatActivity {

    int numero1=0;
    int numero2=0;
    int banderita=-1;
    int res=0;
    Button boton;
    TextView buffer;
    String texto="";
    String texto2="";
    String textofinal="";
    String operador="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buffer= (TextView) findViewById(R.id.buffer);

    }

    public void onClick (View v)
    {

        System.out.println("Id: " + v.getId());

        boton = (Button)v;

        if(boton.getText().toString().equals("X")||
                boton.getText().toString().equals("^")||
                boton.getText().toString().equals("+")||
                boton.getText().toString().equals("-")||
                boton.getText().toString().equals("/")||
                boton.getText().toString().equals("mod")){
            System.out.println("Operacion---");
            if(banderita==-1){
                numero1=Integer.parseInt(texto);
                System.out.println("num1= " + numero1);
                banderita=1;

                texto= texto+boton.getText().toString();
                operador=boton.getText().toString();
                System.out.println("Operador: "+ operador);
                textofinal=texto;
                texto="";
                buffer.setText(textofinal);
            }

        }
        else{
            if(boton.getText().toString().equals("C")){
                textofinal="";
                texto="";
                texto2="";
                numero1=0;
                numero2=0;
                banderita=-1;
                buffer.setText(textofinal);
                System.out.println(textofinal+ " "+ texto + " "+ numero1 + " "+numero2);
            }
            else{
                if(boton.getText().toString().equals("=")){

                        numero2=Integer.parseInt(texto2);
                        System.out.println("num2= " + numero2);

                        if(operador.equals("+")){
                            res=numero1+numero2;
                        }
                        else{
                            if(operador.equals("-")){
                                res=numero1-numero2;
                            }
                            else{
                                if(operador.equals("X")){
                                    res=numero1*numero2;
                                }
                                else{
                                    if(operador.equals("/")){
                                        res=numero1/numero2;
                                    }
                                    else{
                                        if(operador.equals("mod")){
                                            res=numero1 % numero2;
                                        }
                                        else{
                                            if(operador.equals("^")){
                                                res=(int) Math.pow(numero1,numero2);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        textofinal=Integer.toString(res);
                        texto="";
                        texto2="";
                        numero1=0;
                        numero2=0;
                        banderita=-1;
                        buffer.setText(textofinal);
                        textofinal="";
                }
                else{
                    if(banderita==-1){
                        texto= texto+boton.getText().toString();
                        textofinal=texto;
                        buffer.setText(textofinal);
                    }
                    else{
                        if(banderita==1) {
                            texto2 = texto2 + boton.getText().toString();
                            textofinal = textofinal + boton.getText();
                            buffer.setText(textofinal);
                        }
                    }
                }

            }

        }
        System.out.println("banderita= "+banderita);

    }





}
